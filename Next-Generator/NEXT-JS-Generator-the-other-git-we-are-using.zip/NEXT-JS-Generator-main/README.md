# NEXT-JS-Generator


# Command
## Run any of those in a terminal with Node.JS. Remember to remove [] and add a project name instead of this [projectName]


=======
### npx create-next-app [projectName] -e  https://github.com/Bass4Nation/NEXT-JS-Generator/tree/main/next-starter
### npx create-next-app [projectName] -e  https://github.com/Bass4Nation/NEXT-JS-Generator/tree/main/next-starter-pages
### npx create-next-app [projectName] -e  https://github.com/Bass4Nation/NEXT-JS-Generator/tree/main/next-starter-pages-topnav

### To run this project after it is built. Type in terminal "npm run dev" or "yarn run dev".

This is being used with scripts in this repository 
https://github.com/Bass4Nation/Rammeverk2022 

