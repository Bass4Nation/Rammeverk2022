# NEXT-JS-Generator


# Command
## If everything is working as it should. Link below

npx create-next-app [projectName] -e  https://github.com/Bass4Nation/NEXT-JS-Generator/tree/main/next-starter
